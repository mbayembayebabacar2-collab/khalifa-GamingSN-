// Liens publics de la communauté.
// Le lien eFootball est celui fourni par l'administrateur.
// Ajouter les autres liens lorsque leurs canaux seront disponibles.
window.KG_CONFIG = {
  whatsapp: {
    efootball: "https://whatsapp.com/channel/0029Vb7pPZr5Ui2ZxRYXZN1Q",
    easportsfc: "",
    needforspeed: "",
    callofduty: "",
    gta: ""
  },
  feedbackBackendConnected: false
};