KHALIFA GAMING™ — PROJET MULTIGAMING

CONTENU
- index.html : page d'accueil avec les cinq univers.
- efootball.html : page dédiée eFootball™.
- easportsfc.html : page dédiée EA SPORTS FC.
- need-for-speed.html : page dédiée Need for Speed.
- call-of-duty.html : page dédiée Call of Duty.
- gta.html : page dédiée GTA.
- avis.html : formulaire de démonstration des avis.
- style.css : design responsive et couleurs propres à chaque jeu.
- config.js : liens communautaires.

MISE EN LIGNE NETLIFY
1. Extraire le ZIP sur le téléphone ou l'ordinateur.
2. Ouvrir le projet Netlify existant.
3. Dans Deploys, déposer le dossier contenant index.html et les autres fichiers.
4. Ouvrir le site et tester les liens de navigation.

IMPORTANT
Cette version est une maquette statique. Les rubriques et la navigation fonctionnent.
Les actualités sont des emplacements à remplir. Le formulaire d'avis ne sauvegarde rien
et n'envoie aucun e-mail pour le moment. Pour activer votes/avis partagés et notifications,
il faudra connecter un backend sécurisé et le tester.
Le lien WhatsApp fourni est intégré uniquement à la configuration eFootball.
Les autres liens sont laissés vides en attendant les liens officiels de ces communautés.

Les logos et bannières sont des créations graphiques typographiques originales inspirées
des ambiances/couleurs des jeux. Ce projet n'est pas un site officiel des éditeurs.
