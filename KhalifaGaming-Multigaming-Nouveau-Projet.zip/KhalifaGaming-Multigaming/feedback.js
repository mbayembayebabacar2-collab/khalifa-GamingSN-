document.getElementById("feedbackForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const game = document.getElementById("game").value;
  const kind = document.getElementById("kind").value;
  const message = document.getElementById("message").value.trim();
  const notice = document.getElementById("formNotice");
  notice.textContent = "Aperçu prêt — " + game + " / " + kind + " : « " + message + " ». Rien n’a été envoyé ni enregistré. Le backend devra être connecté pour activer les votes, les avis et les notifications e-mail.";
  notice.classList.add("preview");
});